import numpy as np
import itertools
import qutip as qt
from statsmodels.tools.eval_measures import aic

def pauli_basis(m):
    paulis_1q = [qt.identity(2), qt.sigmax(), qt.sigmay(), qt.sigmaz()]
    labels = ['I', 'X', 'Y', 'Z']
    basis = []
    for combo in itertools.product(range(4), repeat=m):
        op = qt.tensor([paulis_1q[i] for i in combo])
        label = ''.join(labels[i] for i in combo)
        basis.append(qt.Qobj(op.full(), label=label))
    return basis

def log_log_regression(ns, norms):
    slope, _ = np.polyfit(np.log(ns), np.log(norms), 1)
    return slope

def semi_log_regression(ns, norms):
    slope, _ = np.polyfit(ns, np.log(norms), 1)
    return -slope

def model_selection(rss_a, rss_b, n, k=2):
    return aic(rss_a, n, k) - aic(rss_b, n, k)

def chebyshev_poly(n):
    return np.random.rand(n + 1)
