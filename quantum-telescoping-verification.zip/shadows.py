import numpy as np
import qutip as qt
from utils import pauli_basis

def classical_shadow_channel(Phi, N_samples, m):
    d = 2 ** m
    paulis = pauli_basis(m)
    estimates = {p.label: [] for p in paulis}

    for _ in range(N_samples):
        rho_in = qt.tensor([qt.rand_dm_ginibre(2) for _ in range(m)])
        rho_out = Phi(rho_in)

        for p in paulis:
            estimates[p.label].append((rho_out * p).tr().real)

    return {k: np.median(v) for k, v in estimates.items()}

def estimate_pauli_norm(Phi_n, Phi_prev, N_samples, m):
    Delta = Phi_n - Phi_prev if Phi_prev is not None else Phi_n
    shadows = classical_shadow_channel(Delta, N_samples, m)
    return max(abs(v) for v in shadows.values()) / np.sqrt(2 ** m)
