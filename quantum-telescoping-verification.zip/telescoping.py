import numpy as np
import qutip as qt
from scipy.linalg import expm
from utils import chebyshev_poly

def heisenberg_hamiltonian(m):
    sigx, sigy, sigz = qt.sigmax(), qt.sigmay(), qt.sigmaz()
    H = qt.Qobj(np.zeros((2**m, 2**m)))
    for i in range(m - 1):
        H += qt.tensor([qt.identity(2)]*i + [sigx, sigx] + [qt.identity(2)]*(m-i-2))
        H += qt.tensor([qt.identity(2)]*i + [sigy, sigy] + [qt.identity(2)]*(m-i-2))
        H += qt.tensor([qt.identity(2)]*i + [sigz, sigz] + [qt.identity(2)]*(m-i-2))
    return H

def trotter_sequence(H, t, n):
    dt = t / n
    U = qt.Qobj(expm(-1j * dt * H.full()))
    return qt.to_super(U ** n)

def qsp_approx(H, t, n):
    spec = np.linalg.eigvals(H.full())
    coeffs = chebyshev_poly(n)
    U_diag = np.diag([np.exp(-1j * t * sum(c * (e ** k) for k, c in enumerate(coeffs)))
                      for e in spec])
    return qt.to_super(qt.Qobj(U_diag))

def amplitude_damping_channel(gamma, t, n=None):
    if n is None:
        E0 = qt.Qobj([[1, 0], [0, np.exp(-gamma*t/2)]])
        E1 = qt.Qobj([[0, np.sqrt(1 - np.exp(-gamma*t))], [0, 0]])
        return qt.to_super(qt.kraus_to_super([E0, E1]))
    else:
        dt = t / n
        E0 = qt.Qobj([[1, 0], [0, np.exp(-gamma*dt/2)]])
        E1 = qt.Qobj([[0, np.sqrt(1 - np.exp(-gamma*dt))], [0, 0]])
        Phi_dt = qt.to_super(qt.kraus_to_super([E0, E1]))
        return Phi_dt ** n
