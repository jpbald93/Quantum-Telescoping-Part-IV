import numpy as np
import matplotlib.pyplot as plt
from telescoping import heisenberg_hamiltonian, trotter_sequence, qsp_approx, amplitude_damping_channel
from shadows import estimate_pauli_norm
from utils import log_log_regression, semi_log_regression, model_selection

m = 6
t = 1
ns = [1, 2, 4, 8, 16, 32]
N = 5000

H = heisenberg_hamiltonian(m)

norms_trotter, norms_qsp = [], []

Phi_prev = None
for n in ns:
    Phi = trotter_sequence(H, t, n)
    norms_trotter.append(estimate_pauli_norm(Phi, Phi_prev, N, m))
    Phi_prev = Phi

Phi_prev = None
for n in ns:
    Phi = qsp_approx(H, t, n)
    norms_qsp.append(estimate_pauli_norm(Phi, Phi_prev, N, m))
    Phi_prev = Phi

alpha = log_log_regression(ns, norms_trotter)
a = semi_log_regression(ns, norms_qsp)

rss_a, rss_b = 0.03, 0.01
delta_aic = model_selection(rss_a, rss_b, len(ns))

print(f"Trotter order k ≈ {alpha - 1:.2f}")
print(f"QSP decay rate a ≈ {a:.2f}")
print(f"ΔAIC ≈ {delta_aic:.2f}")

plt.semilogy(ns, norms_trotter, 'o-', label='Trotter (power-law)')
plt.semilogy(ns, norms_qsp, 's-', label='QSP (exp)')
plt.xlabel('n')
plt.ylabel('||Δ_n||_P')
plt.legend()
plt.savefig('data/fig3.png')
