# Quantum Telescoping Verification

Reproduces numerical examples from *Quantum Telescoping Part IV* (Bald, 2026).
Simulates channel increments, estimates Pauli witness norms via classical shadows,
and distinguishes decay regimes (power-law vs exponential) using model selection (AIC).

## Setup
- Python 3.12+
- Install dependencies:
  pip install -r requirements.txt
- Run:
  python example.py

Outputs plots and results to the `data/` directory.

## Key Features
- Heisenberg chain (m=6, t=1):
  - Trotter (power-law k ≈ 1)
  - QSP-style polynomial approximation (exponential a ≈ 0.7)
- Amplitude damping (m=1, γ=1):
  - Confirms polynomial telescoping
- Classical shadows:
  - Emulates N = 5000 measurements (ε ≈ 0.05)
- Demonstrates measurement-efficient verification without full tomography

Contact: jpbald93@gmail.com
